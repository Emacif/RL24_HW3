# admittance controller
Admittance controller for the KUKA iiwa robot. The admittance controller commands a group of joints through the position or velocity interface. It requires interaction force sensor data.
